About
=====
Get to know the project and the community. Learn where we are going and how we work
together.

.. toctree::
    :maxdepth: 1

    values
    code_of_conduct
    Governance and decision-making <../skips/1-governance>
