Development
===========

Below you will find resources about the development of scikit-image.

.. toctree::
    :maxdepth: 1

    contribute
    ../gitwash/index
    core_developer
    ../skips/index
