Examples for developers
-----------------------
In this folder, we have examples for advanced topics, including detailed
explanations of the inner workings of certain algorithms.

These examples require some basic knowledge of image processing. They are
targeted at existing or would-be scikit-image developers wishing to develop
their knowledge of image processing algorithms.
