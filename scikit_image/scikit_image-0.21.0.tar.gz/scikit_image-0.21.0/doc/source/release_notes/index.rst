Release notes
=============

This is the list of changes to scikit-image between each release. For full details, see
the `commit logs`_.

.. _commit logs: https://github.com/scikit-image/scikit-image/commits/

.. naturalsortedtoctree::
    :maxdepth: 1
    :glob:
    :reversed:

    release_[0-9d]*
