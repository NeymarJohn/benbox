# License

```{literalinclude} ../../LICENSE.txt

```
