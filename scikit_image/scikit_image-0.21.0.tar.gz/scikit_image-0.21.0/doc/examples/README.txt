.. _examples_gallery:

Examples
========

A gallery of examples and that showcase how scikit-image can be used. Some
examples demonstrate the use of the API in general and some demonstrate specific
applications in tutorial form.

.. hint::

    Check out our :ref:`user_guide` for a narrative
    introduction to key library conventions and basic image manipulation.
