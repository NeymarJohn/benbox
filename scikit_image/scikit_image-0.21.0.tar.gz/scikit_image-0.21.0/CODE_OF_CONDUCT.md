[scikit-image Code of Conduct](doc/source/about/code_of_conduct.md)
